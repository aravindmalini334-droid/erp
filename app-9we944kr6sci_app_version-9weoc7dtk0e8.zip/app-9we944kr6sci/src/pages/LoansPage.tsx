import React, { useState, useEffect } from 'react';
import { Plus, Download, Upload, RefreshCw, DollarSign } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { toast } from 'sonner';
import {
  getLoans,
  createLoan,
  getLoanCollections,
  createLoanCollection,
  getMembers,
} from '@/db/api';
import type { Loan, LoanCollection, Member } from '@/types';
import { exportToExcel, importFromExcel, formatDateForExcel, parseDateFromExcel } from '@/lib/excel';

const loanSchema = z.object({
  member_id: z.string().min(1, 'Member is required'),
  loan_amount: z.string().min(1, 'Loan amount is required'),
  disbursement_date: z.string().min(1, 'Disbursement date is required'),
  notes: z.string().optional(),
});

const collectionSchema = z.object({
  loan_id: z.string().min(1, 'Loan is required'),
  collection_amount: z.string().min(1, 'Collection amount is required'),
  collection_date: z.string().min(1, 'Collection date is required'),
  notes: z.string().optional(),
});

type LoanFormData = z.infer<typeof loanSchema>;
type CollectionFormData = z.infer<typeof collectionSchema>;

const LoansPage: React.FC = () => {
  const [loans, setLoans] = useState<Loan[]>([]);
  const [collections, setCollections] = useState<LoanCollection[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [loanDialogOpen, setLoanDialogOpen] = useState(false);
  const [collectionDialogOpen, setCollectionDialogOpen] = useState(false);

  const loanForm = useForm<LoanFormData>({
    resolver: zodResolver(loanSchema),
    defaultValues: {
      member_id: '',
      loan_amount: '',
      disbursement_date: new Date().toISOString().split('T')[0],
      notes: '',
    },
  });

  const collectionForm = useForm<CollectionFormData>({
    resolver: zodResolver(collectionSchema),
    defaultValues: {
      loan_id: '',
      collection_amount: '',
      collection_date: new Date().toISOString().split('T')[0],
      notes: '',
    },
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async (isRefresh = false) => {
    try {
      if (isRefresh) {
        setRefreshing(true);
      } else {
        setLoading(true);
      }
      const [loansData, collectionsData, membersData] = await Promise.all([
        getLoans(),
        getLoanCollections(),
        getMembers(),
      ]);
      setLoans(loansData);
      setCollections(collectionsData);
      setMembers(membersData);
      if (isRefresh) {
        toast.success('Data refreshed');
      }
    } catch (error) {
      toast.error('Failed to load data');
      console.error(error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onLoanSubmit = async (data: LoanFormData) => {
    try {
      await createLoan({
        member_id: data.member_id,
        loan_amount: parseFloat(data.loan_amount),
        disbursement_date: data.disbursement_date,
        status: 'active',
        notes: data.notes || null,
      });

      toast.success('Loan disbursed successfully');
      setLoanDialogOpen(false);
      loanForm.reset();
      loadData();
    } catch (error) {
      toast.error('Failed to disburse loan');
      console.error(error);
    }
  };

  const onCollectionSubmit = async (data: CollectionFormData) => {
    try {
      await createLoanCollection({
        loan_id: data.loan_id,
        collection_amount: parseFloat(data.collection_amount),
        collection_date: data.collection_date,
        notes: data.notes || null,
      });

      toast.success('Loan collection recorded successfully');
      setCollectionDialogOpen(false);
      collectionForm.reset();
      loadData();
    } catch (error) {
      toast.error('Failed to record collection');
      console.error(error);
    }
  };

  const handleExportLoans = () => {
    const exportData = loans.map((loan) => ({
      'Member Number': loan.member?.member_number || '',
      'Member Name': loan.member?.name || '',
      'Loan Amount': loan.loan_amount,
      'Disbursement Date': formatDateForExcel(loan.disbursement_date),
      Status: loan.status,
      Notes: loan.notes || '',
    }));

    exportToExcel(exportData, 'loans', 'Loans');
    toast.success('Loans exported successfully');
  };

  const handleExportCollections = () => {
    const exportData = collections.map((collection) => ({
      'Member Number': collection.loan?.member?.member_number || '',
      'Member Name': collection.loan?.member?.name || '',
      'Collection Amount': collection.collection_amount,
      'Collection Date': formatDateForExcel(collection.collection_date),
      Notes: collection.notes || '',
    }));

    exportToExcel(exportData, 'loan_collections', 'Collections');
    toast.success('Collections exported successfully');
  };

  const handleImportLoans = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const data = await importFromExcel(file);
      
      for (const row of data) {
        const memberNumber = row['Member Number'] || row['member_number'];
        const member = members.find((m) => m.member_number === memberNumber);
        
        if (member) {
          await createLoan({
            member_id: member.id,
            loan_amount: parseFloat(row['Loan Amount'] || row['loan_amount'] || '0'),
            disbursement_date: parseDateFromExcel(row['Disbursement Date'] || row['disbursement_date']) || new Date().toISOString().split('T')[0],
            status: row['Status'] || row['status'] || 'active',
            notes: row['Notes'] || row['notes'] || null,
          });
        }
      }

      toast.success(`Imported ${data.length} loans successfully`);
      loadData();
    } catch (error) {
      toast.error('Failed to import loans');
      console.error(error);
    }

    event.target.value = '';
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-primary text-primary-foreground py-4 px-4 sticky top-0 z-10 shadow-md">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-bold">Loans</h1>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => loadData(true)}
            disabled={refreshing}
            className="text-primary-foreground hover:bg-primary-foreground/20"
          >
            <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </div>

      <div className="p-4">
        <Tabs defaultValue="disbursements" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-4">
            <TabsTrigger value="disbursements">Disbursements</TabsTrigger>
            <TabsTrigger value="collections">Collections</TabsTrigger>
          </TabsList>

          <TabsContent value="disbursements" className="space-y-4 mt-0">
            <div className="flex flex-wrap gap-2">
              <Button onClick={handleExportLoans} variant="outline" size="sm" className="flex-1 min-w-[100px]">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
              <Button variant="outline" size="sm" asChild className="flex-1 min-w-[100px]">
                <label htmlFor="import-loans" className="cursor-pointer flex items-center justify-center">
                  <Upload className="h-4 w-4 mr-2" />
                  Import
                  <input
                    id="import-loans"
                    type="file"
                    accept=".xlsx,.xls"
                    onChange={handleImportLoans}
                    className="hidden"
                  />
                </label>
              </Button>
              <Dialog open={loanDialogOpen} onOpenChange={setLoanDialogOpen}>
                <DialogTrigger asChild>
                  <Button size="sm" className="flex-1 min-w-[100px]">
                    <Plus className="h-4 w-4 mr-2" />
                    Disburse
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-[95vw] w-full max-h-[85vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Disburse New Loan</DialogTitle>
                  </DialogHeader>
                  <Form {...loanForm}>
                    <form onSubmit={loanForm.handleSubmit(onLoanSubmit)} className="space-y-4">
                      <FormField
                        control={loanForm.control}
                        name="member_id"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Member</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select member" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {members.map((member) => (
                                  <SelectItem key={member.id} value={member.id}>
                                    {member.member_number} - {member.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={loanForm.control}
                        name="loan_amount"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Loan Amount</FormLabel>
                            <FormControl>
                              <Input {...field} type="number" step="0.01" placeholder="0.00" inputMode="decimal" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={loanForm.control}
                        name="disbursement_date"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Disbursement Date</FormLabel>
                            <FormControl>
                              <Input {...field} type="date" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={loanForm.control}
                        name="notes"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Notes</FormLabel>
                            <FormControl>
                              <Textarea {...field} placeholder="Optional notes" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <Button type="submit" className="w-full">
                        Disburse Loan
                      </Button>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>

            {loading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <Card key={i}>
                    <CardContent className="p-4">
                      <Skeleton className="h-4 w-24 mb-2 bg-muted" />
                      <Skeleton className="h-6 w-full mb-2 bg-muted" />
                      <Skeleton className="h-4 w-32 bg-muted" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : loans.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <DollarSign className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">
                    No loans found. Disburse your first loan to get started.
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {loans.map((loan) => (
                  <Card key={loan.id}>
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex-1">
                          <h3 className="font-semibold">{loan.member?.name}</h3>
                          <p className="text-xs text-muted-foreground">{loan.member?.member_number}</p>
                        </div>
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-primary/10 text-primary">
                          {loan.status}
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div>
                          <p className="text-muted-foreground text-xs">Amount</p>
                          <p className="font-medium">${loan.loan_amount.toFixed(2)}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground text-xs">Date</p>
                          <p className="font-medium">{new Date(loan.disbursement_date).toLocaleDateString()}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="collections" className="space-y-4 mt-0">
            <div className="flex flex-wrap gap-2">
              <Button onClick={handleExportCollections} variant="outline" size="sm" className="flex-1 min-w-[120px]">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
              <Dialog open={collectionDialogOpen} onOpenChange={setCollectionDialogOpen}>
                <DialogTrigger asChild>
                  <Button size="sm" className="flex-1 min-w-[120px]">
                    <Plus className="h-4 w-4 mr-2" />
                    Record
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-[95vw] w-full max-h-[85vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Record Loan Collection</DialogTitle>
                  </DialogHeader>
                  <Form {...collectionForm}>
                    <form
                      onSubmit={collectionForm.handleSubmit(onCollectionSubmit)}
                      className="space-y-4"
                    >
                      <FormField
                        control={collectionForm.control}
                        name="loan_id"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Loan</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select loan" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {loans
                                  .filter((loan) => loan.status === 'active')
                                  .map((loan) => (
                                    <SelectItem key={loan.id} value={loan.id}>
                                      {loan.member?.name} - ${loan.loan_amount.toFixed(2)}
                                    </SelectItem>
                                  ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={collectionForm.control}
                        name="collection_amount"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Collection Amount</FormLabel>
                            <FormControl>
                              <Input {...field} type="number" step="0.01" placeholder="0.00" inputMode="decimal" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={collectionForm.control}
                        name="collection_date"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Collection Date</FormLabel>
                            <FormControl>
                              <Input {...field} type="date" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={collectionForm.control}
                        name="notes"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Notes</FormLabel>
                            <FormControl>
                              <Textarea {...field} placeholder="Optional notes" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <Button type="submit" className="w-full">
                        Record Collection
                      </Button>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>

            {loading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <Card key={i}>
                    <CardContent className="p-4">
                      <Skeleton className="h-4 w-24 mb-2 bg-muted" />
                      <Skeleton className="h-6 w-full mb-2 bg-muted" />
                      <Skeleton className="h-4 w-32 bg-muted" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : collections.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <DollarSign className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">
                    No collections found. Record your first collection to get started.
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {collections.map((collection) => (
                  <Card key={collection.id}>
                    <CardContent className="p-4">
                      <div className="mb-2">
                        <h3 className="font-semibold">{collection.loan?.member?.name}</h3>
                        <p className="text-xs text-muted-foreground">{collection.loan?.member?.member_number}</p>
                      </div>
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div>
                          <p className="text-muted-foreground text-xs">Amount</p>
                          <p className="font-medium">${collection.collection_amount.toFixed(2)}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground text-xs">Date</p>
                          <p className="font-medium">{new Date(collection.collection_date).toLocaleDateString()}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default LoansPage;
