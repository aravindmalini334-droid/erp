import React, { useState, useEffect } from 'react';
import { Plus, Download, RefreshCw, BookOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { toast } from 'sonner';
import {
  getDayBookEntries,
  createDayBookEntry,
  getGeneralLedgerEntries,
  createGeneralLedgerEntry,
  getLoanLedgerEntries,
  createLoanLedgerEntry,
  getExpensesLedgerEntries,
  createExpensesLedgerEntry,
  getMembers,
} from '@/db/api';
import type {
  DayBook,
  GeneralLedger,
  LoanLedger,
  ExpensesLedger,
  Member,
} from '@/types';
import { exportToExcel, formatDateForExcel } from '@/lib/excel';

const dayBookSchema = z.object({
  entry_date: z.string().min(1, 'Date is required'),
  description: z.string().min(1, 'Description is required'),
  debit: z.string().optional(),
  credit: z.string().optional(),
});

const generalLedgerSchema = z.object({
  entry_date: z.string().min(1, 'Date is required'),
  account_name: z.string().min(1, 'Account name is required'),
  description: z.string().min(1, 'Description is required'),
  debit: z.string().optional(),
  credit: z.string().optional(),
});

const loanLedgerSchema = z.object({
  entry_date: z.string().min(1, 'Date is required'),
  member_id: z.string().optional(),
  description: z.string().min(1, 'Description is required'),
  debit: z.string().optional(),
  credit: z.string().optional(),
});

const expensesLedgerSchema = z.object({
  entry_date: z.string().min(1, 'Date is required'),
  description: z.string().min(1, 'Description is required'),
  amount: z.string().min(1, 'Amount is required'),
  voucher_number: z.string().optional(),
});

type DayBookFormData = z.infer<typeof dayBookSchema>;
type GeneralLedgerFormData = z.infer<typeof generalLedgerSchema>;
type LoanLedgerFormData = z.infer<typeof loanLedgerSchema>;
type ExpensesLedgerFormData = z.infer<typeof expensesLedgerSchema>;

const LedgersPage: React.FC = () => {
  const [dayBookEntries, setDayBookEntries] = useState<DayBook[]>([]);
  const [generalLedgerEntries, setGeneralLedgerEntries] = useState<GeneralLedger[]>([]);
  const [loanLedgerEntries, setLoanLedgerEntries] = useState<LoanLedger[]>([]);
  const [expensesLedgerEntries, setExpensesLedgerEntries] = useState<ExpensesLedger[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [dialogOpen, setDialogOpen] = useState<string | null>(null);

  const dayBookForm = useForm<DayBookFormData>({
    resolver: zodResolver(dayBookSchema),
    defaultValues: {
      entry_date: new Date().toISOString().split('T')[0],
      description: '',
      debit: '0',
      credit: '0',
    },
  });

  const generalLedgerForm = useForm<GeneralLedgerFormData>({
    resolver: zodResolver(generalLedgerSchema),
    defaultValues: {
      entry_date: new Date().toISOString().split('T')[0],
      account_name: '',
      description: '',
      debit: '0',
      credit: '0',
    },
  });

  const loanLedgerForm = useForm<LoanLedgerFormData>({
    resolver: zodResolver(loanLedgerSchema),
    defaultValues: {
      entry_date: new Date().toISOString().split('T')[0],
      member_id: '',
      description: '',
      debit: '0',
      credit: '0',
    },
  });

  const expensesLedgerForm = useForm<ExpensesLedgerFormData>({
    resolver: zodResolver(expensesLedgerSchema),
    defaultValues: {
      entry_date: new Date().toISOString().split('T')[0],
      description: '',
      amount: '',
      voucher_number: '',
    },
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async (isRefresh = false) => {
    try {
      if (isRefresh) {
        setRefreshing(true);
      } else {
        setLoading(true);
      }
      const [dayBook, generalLedger, loanLedger, expensesLedger, membersData] = await Promise.all([
        getDayBookEntries(),
        getGeneralLedgerEntries(),
        getLoanLedgerEntries(),
        getExpensesLedgerEntries(),
        getMembers(),
      ]);
      setDayBookEntries(dayBook);
      setGeneralLedgerEntries(generalLedger);
      setLoanLedgerEntries(loanLedger);
      setExpensesLedgerEntries(expensesLedger);
      setMembers(membersData);
      if (isRefresh) {
        toast.success('Data refreshed');
      }
    } catch (error) {
      toast.error('Failed to load ledger data');
      console.error(error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onDayBookSubmit = async (data: DayBookFormData) => {
    try {
      await createDayBookEntry({
        entry_date: data.entry_date,
        description: data.description,
        debit: parseFloat(data.debit || '0'),
        credit: parseFloat(data.credit || '0'),
      });

      toast.success('Day book entry added successfully');
      setDialogOpen(null);
      dayBookForm.reset();
      loadData();
    } catch (error) {
      toast.error('Failed to add entry');
      console.error(error);
    }
  };

  const onGeneralLedgerSubmit = async (data: GeneralLedgerFormData) => {
    try {
      await createGeneralLedgerEntry({
        entry_date: data.entry_date,
        account_name: data.account_name,
        description: data.description,
        debit: parseFloat(data.debit || '0'),
        credit: parseFloat(data.credit || '0'),
      });

      toast.success('General ledger entry added successfully');
      setDialogOpen(null);
      generalLedgerForm.reset();
      loadData();
    } catch (error) {
      toast.error('Failed to add entry');
      console.error(error);
    }
  };

  const onLoanLedgerSubmit = async (data: LoanLedgerFormData) => {
    try {
      await createLoanLedgerEntry({
        entry_date: data.entry_date,
        member_id: data.member_id || null,
        description: data.description,
        debit: parseFloat(data.debit || '0'),
        credit: parseFloat(data.credit || '0'),
      });

      toast.success('Loan ledger entry added successfully');
      setDialogOpen(null);
      loanLedgerForm.reset();
      loadData();
    } catch (error) {
      toast.error('Failed to add entry');
      console.error(error);
    }
  };

  const onExpensesLedgerSubmit = async (data: ExpensesLedgerFormData) => {
    try {
      await createExpensesLedgerEntry({
        entry_date: data.entry_date,
        description: data.description,
        amount: parseFloat(data.amount),
        voucher_number: data.voucher_number || null,
      });

      toast.success('Expenses ledger entry added successfully');
      setDialogOpen(null);
      expensesLedgerForm.reset();
      loadData();
    } catch (error) {
      toast.error('Failed to add entry');
      console.error(error);
    }
  };

  const handleExportDayBook = () => {
    const exportData = dayBookEntries.map((entry) => ({
      Date: formatDateForExcel(entry.entry_date),
      Description: entry.description,
      Debit: entry.debit,
      Credit: entry.credit,
    }));

    exportToExcel(exportData, 'day_book', 'Day Book');
    toast.success('Day book exported successfully');
  };

  const handleExportGeneralLedger = () => {
    const exportData = generalLedgerEntries.map((entry) => ({
      Date: formatDateForExcel(entry.entry_date),
      Account: entry.account_name,
      Description: entry.description,
      Debit: entry.debit,
      Credit: entry.credit,
    }));

    exportToExcel(exportData, 'general_ledger', 'General Ledger');
    toast.success('General ledger exported successfully');
  };

  const handleExportLoanLedger = () => {
    const exportData = loanLedgerEntries.map((entry) => ({
      Date: formatDateForExcel(entry.entry_date),
      Member: entry.member?.name || '',
      Description: entry.description,
      Debit: entry.debit,
      Credit: entry.credit,
    }));

    exportToExcel(exportData, 'loan_ledger', 'Loan Ledger');
    toast.success('Loan ledger exported successfully');
  };

  const handleExportExpensesLedger = () => {
    const exportData = expensesLedgerEntries.map((entry) => ({
      Date: formatDateForExcel(entry.entry_date),
      Description: entry.description,
      Amount: entry.amount,
      'Voucher Number': entry.voucher_number || '',
    }));

    exportToExcel(exportData, 'expenses_ledger', 'Expenses Ledger');
    toast.success('Expenses ledger exported successfully');
  };

  const renderLedgerCard = (entry: any, type: string) => (
    <Card key={entry.id}>
      <CardContent className="p-4">
        <div className="flex justify-between items-start mb-2">
          <p className="text-sm font-medium">{new Date(entry.entry_date).toLocaleDateString()}</p>
          {type === 'expenses' && entry.voucher_number && (
            <span className="text-xs text-muted-foreground">#{entry.voucher_number}</span>
          )}
        </div>
        <p className="text-sm mb-2">{entry.description}</p>
        {type === 'general' && (
          <p className="text-xs text-muted-foreground mb-2">{entry.account_name}</p>
        )}
        {type === 'loan' && entry.member && (
          <p className="text-xs text-muted-foreground mb-2">{entry.member.name}</p>
        )}
        <div className="grid grid-cols-2 gap-3 text-sm">
          {type === 'expenses' ? (
            <div>
              <p className="text-muted-foreground text-xs">Amount</p>
              <p className="font-medium">${entry.amount.toFixed(2)}</p>
            </div>
          ) : (
            <>
              <div>
                <p className="text-muted-foreground text-xs">Debit</p>
                <p className="font-medium">${entry.debit.toFixed(2)}</p>
              </div>
              <div>
                <p className="text-muted-foreground text-xs">Credit</p>
                <p className="font-medium">${entry.credit.toFixed(2)}</p>
              </div>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-primary text-primary-foreground py-4 px-4 sticky top-0 z-10 shadow-md">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-bold">Ledgers</h1>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => loadData(true)}
            disabled={refreshing}
            className="text-primary-foreground hover:bg-primary-foreground/20"
          >
            <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </div>

      <div className="p-4">
        <Tabs defaultValue="daybook" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-4">
            <TabsTrigger value="daybook" className="text-xs">Day</TabsTrigger>
            <TabsTrigger value="general" className="text-xs">General</TabsTrigger>
            <TabsTrigger value="loan" className="text-xs">Loan</TabsTrigger>
            <TabsTrigger value="expenses" className="text-xs">Expenses</TabsTrigger>
          </TabsList>

          <TabsContent value="daybook" className="space-y-4 mt-0">
            <div className="flex gap-2">
              <Button onClick={handleExportDayBook} variant="outline" size="sm" className="flex-1">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
              <Dialog open={dialogOpen === 'daybook'} onOpenChange={(open) => setDialogOpen(open ? 'daybook' : null)}>
                <DialogTrigger asChild>
                  <Button size="sm" className="flex-1">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Entry
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-[95vw] w-full max-h-[85vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Add Day Book Entry</DialogTitle>
                  </DialogHeader>
                  <Form {...dayBookForm}>
                    <form onSubmit={dayBookForm.handleSubmit(onDayBookSubmit)} className="space-y-4">
                      <FormField
                        control={dayBookForm.control}
                        name="entry_date"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Date</FormLabel>
                            <FormControl>
                              <Input {...field} type="date" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={dayBookForm.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Description</FormLabel>
                            <FormControl>
                              <Textarea {...field} placeholder="Enter description" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={dayBookForm.control}
                          name="debit"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Debit</FormLabel>
                              <FormControl>
                                <Input {...field} type="number" step="0.01" placeholder="0.00" inputMode="decimal" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={dayBookForm.control}
                          name="credit"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Credit</FormLabel>
                              <FormControl>
                                <Input {...field} type="number" step="0.01" placeholder="0.00" inputMode="decimal" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      <Button type="submit" className="w-full">
                        Add Entry
                      </Button>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>

            {loading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <Card key={i}>
                    <CardContent className="p-4">
                      <Skeleton className="h-4 w-24 mb-2 bg-muted" />
                      <Skeleton className="h-6 w-full mb-2 bg-muted" />
                      <Skeleton className="h-4 w-32 bg-muted" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : dayBookEntries.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <BookOpen className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">
                    No entries found. Add your first entry to get started.
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {dayBookEntries.map((entry) => renderLedgerCard(entry, 'daybook'))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="general" className="space-y-4 mt-0">
            <div className="flex gap-2">
              <Button onClick={handleExportGeneralLedger} variant="outline" size="sm" className="flex-1">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
              <Dialog open={dialogOpen === 'general'} onOpenChange={(open) => setDialogOpen(open ? 'general' : null)}>
                <DialogTrigger asChild>
                  <Button size="sm" className="flex-1">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Entry
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-[95vw] w-full max-h-[85vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Add General Ledger Entry</DialogTitle>
                  </DialogHeader>
                  <Form {...generalLedgerForm}>
                    <form onSubmit={generalLedgerForm.handleSubmit(onGeneralLedgerSubmit)} className="space-y-4">
                      <FormField
                        control={generalLedgerForm.control}
                        name="entry_date"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Date</FormLabel>
                            <FormControl>
                              <Input {...field} type="date" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={generalLedgerForm.control}
                        name="account_name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Account Name</FormLabel>
                            <FormControl>
                              <Input {...field} placeholder="Enter account name" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={generalLedgerForm.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Description</FormLabel>
                            <FormControl>
                              <Textarea {...field} placeholder="Enter description" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={generalLedgerForm.control}
                          name="debit"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Debit</FormLabel>
                              <FormControl>
                                <Input {...field} type="number" step="0.01" placeholder="0.00" inputMode="decimal" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={generalLedgerForm.control}
                          name="credit"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Credit</FormLabel>
                              <FormControl>
                                <Input {...field} type="number" step="0.01" placeholder="0.00" inputMode="decimal" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      <Button type="submit" className="w-full">
                        Add Entry
                      </Button>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>

            {loading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <Card key={i}>
                    <CardContent className="p-4">
                      <Skeleton className="h-4 w-24 mb-2 bg-muted" />
                      <Skeleton className="h-6 w-full mb-2 bg-muted" />
                      <Skeleton className="h-4 w-32 bg-muted" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : generalLedgerEntries.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <BookOpen className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">
                    No entries found. Add your first entry to get started.
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {generalLedgerEntries.map((entry) => renderLedgerCard(entry, 'general'))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="loan" className="space-y-4 mt-0">
            <div className="flex gap-2">
              <Button onClick={handleExportLoanLedger} variant="outline" size="sm" className="flex-1">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
              <Dialog open={dialogOpen === 'loan'} onOpenChange={(open) => setDialogOpen(open ? 'loan' : null)}>
                <DialogTrigger asChild>
                  <Button size="sm" className="flex-1">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Entry
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-[95vw] w-full max-h-[85vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Add Loan Ledger Entry</DialogTitle>
                  </DialogHeader>
                  <Form {...loanLedgerForm}>
                    <form onSubmit={loanLedgerForm.handleSubmit(onLoanLedgerSubmit)} className="space-y-4">
                      <FormField
                        control={loanLedgerForm.control}
                        name="entry_date"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Date</FormLabel>
                            <FormControl>
                              <Input {...field} type="date" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={loanLedgerForm.control}
                        name="member_id"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Member (Optional)</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select member" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {members.map((member) => (
                                  <SelectItem key={member.id} value={member.id}>
                                    {member.member_number} - {member.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={loanLedgerForm.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Description</FormLabel>
                            <FormControl>
                              <Textarea {...field} placeholder="Enter description" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={loanLedgerForm.control}
                          name="debit"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Debit</FormLabel>
                              <FormControl>
                                <Input {...field} type="number" step="0.01" placeholder="0.00" inputMode="decimal" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={loanLedgerForm.control}
                          name="credit"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Credit</FormLabel>
                              <FormControl>
                                <Input {...field} type="number" step="0.01" placeholder="0.00" inputMode="decimal" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      <Button type="submit" className="w-full">
                        Add Entry
                      </Button>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>

            {loading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <Card key={i}>
                    <CardContent className="p-4">
                      <Skeleton className="h-4 w-24 mb-2 bg-muted" />
                      <Skeleton className="h-6 w-full mb-2 bg-muted" />
                      <Skeleton className="h-4 w-32 bg-muted" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : loanLedgerEntries.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <BookOpen className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">
                    No entries found. Add your first entry to get started.
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {loanLedgerEntries.map((entry) => renderLedgerCard(entry, 'loan'))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="expenses" className="space-y-4 mt-0">
            <div className="flex gap-2">
              <Button onClick={handleExportExpensesLedger} variant="outline" size="sm" className="flex-1">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
              <Dialog open={dialogOpen === 'expenses'} onOpenChange={(open) => setDialogOpen(open ? 'expenses' : null)}>
                <DialogTrigger asChild>
                  <Button size="sm" className="flex-1">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Entry
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-[95vw] w-full max-h-[85vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Add Expenses Ledger Entry</DialogTitle>
                  </DialogHeader>
                  <Form {...expensesLedgerForm}>
                    <form onSubmit={expensesLedgerForm.handleSubmit(onExpensesLedgerSubmit)} className="space-y-4">
                      <FormField
                        control={expensesLedgerForm.control}
                        name="entry_date"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Date</FormLabel>
                            <FormControl>
                              <Input {...field} type="date" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={expensesLedgerForm.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Description</FormLabel>
                            <FormControl>
                              <Textarea {...field} placeholder="Enter description" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={expensesLedgerForm.control}
                        name="amount"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Amount</FormLabel>
                            <FormControl>
                              <Input {...field} type="number" step="0.01" placeholder="0.00" inputMode="decimal" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={expensesLedgerForm.control}
                        name="voucher_number"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Voucher Number</FormLabel>
                            <FormControl>
                              <Input {...field} placeholder="Optional voucher number" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <Button type="submit" className="w-full">
                        Add Entry
                      </Button>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>

            {loading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <Card key={i}>
                    <CardContent className="p-4">
                      <Skeleton className="h-4 w-24 mb-2 bg-muted" />
                      <Skeleton className="h-6 w-full mb-2 bg-muted" />
                      <Skeleton className="h-4 w-32 bg-muted" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : expensesLedgerEntries.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <BookOpen className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">
                    No entries found. Add your first entry to get started.
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {expensesLedgerEntries.map((entry) => renderLedgerCard(entry, 'expenses'))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default LedgersPage;
