import HomePage from './pages/HomePage';
import MembersPage from './pages/MembersPage';
import LoansPage from './pages/LoansPage';
import BorrowingsPage from './pages/BorrowingsPage';
import LedgersPage from './pages/LedgersPage';
import type { ReactNode } from 'react';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Home',
    path: '/',
    element: <HomePage />
  },
  {
    name: 'Members',
    path: '/members',
    element: <MembersPage />
  },
  {
    name: 'Loans',
    path: '/loans',
    element: <LoansPage />
  },
  {
    name: 'Borrowings',
    path: '/borrowings',
    element: <BorrowingsPage />
  },
  {
    name: 'Ledgers',
    path: '/ledgers',
    element: <LedgersPage />
  }
];

export default routes;
