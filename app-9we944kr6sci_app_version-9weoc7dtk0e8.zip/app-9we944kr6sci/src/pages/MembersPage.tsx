import React, { useState, useEffect } from 'react';
import { Plus, Download, Upload, Pencil, Trash2, RefreshCw, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { toast } from 'sonner';
import { getMembers, createMember, updateMember, deleteMember } from '@/db/api';
import type { Member } from '@/types';
import { exportToExcel, importFromExcel, formatDateForExcel, parseDateFromExcel } from '@/lib/excel';

const memberSchema = z.object({
  member_number: z.string().min(1, 'Member number is required'),
  name: z.string().min(1, 'Name is required'),
  dob: z.string().optional(),
  retirement_date: z.string().optional(),
  share_amount: z.string().optional(),
  thrift_deposit: z.string().optional(),
});

type MemberFormData = z.infer<typeof memberSchema>;

const MembersPage: React.FC = () => {
  const [members, setMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<Member | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [memberToDelete, setMemberToDelete] = useState<string | null>(null);

  const form = useForm<MemberFormData>({
    resolver: zodResolver(memberSchema),
    defaultValues: {
      member_number: '',
      name: '',
      dob: '',
      retirement_date: '',
      share_amount: '0',
      thrift_deposit: '0',
    },
  });

  useEffect(() => {
    loadMembers();
  }, []);

  const loadMembers = async (isRefresh = false) => {
    try {
      if (isRefresh) {
        setRefreshing(true);
      } else {
        setLoading(true);
      }
      const data = await getMembers();
      setMembers(data);
      if (isRefresh) {
        toast.success('Members refreshed');
      }
    } catch (error) {
      toast.error('Failed to load members');
      console.error(error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onSubmit = async (data: MemberFormData) => {
    try {
      const memberData = {
        member_number: data.member_number,
        name: data.name,
        dob: data.dob || null,
        retirement_date: data.retirement_date || null,
        share_amount: parseFloat(data.share_amount || '0'),
        thrift_deposit: parseFloat(data.thrift_deposit || '0'),
      };

      if (editingMember) {
        await updateMember(editingMember.id, memberData);
        toast.success('Member updated successfully');
      } else {
        await createMember(memberData);
        toast.success('Member created successfully');
      }

      setDialogOpen(false);
      setEditingMember(null);
      form.reset();
      loadMembers();
    } catch (error) {
      toast.error('Failed to save member');
      console.error(error);
    }
  };

  const handleEdit = (member: Member) => {
    setEditingMember(member);
    form.reset({
      member_number: member.member_number,
      name: member.name,
      dob: member.dob || '',
      retirement_date: member.retirement_date || '',
      share_amount: member.share_amount.toString(),
      thrift_deposit: member.thrift_deposit.toString(),
    });
    setDialogOpen(true);
  };

  const handleDelete = async () => {
    if (!memberToDelete) return;

    try {
      await deleteMember(memberToDelete);
      toast.success('Member deleted successfully');
      setDeleteDialogOpen(false);
      setMemberToDelete(null);
      loadMembers();
    } catch (error) {
      toast.error('Failed to delete member');
      console.error(error);
    }
  };

  const handleExport = () => {
    const exportData = members.map((member) => ({
      'Member Number': member.member_number,
      Name: member.name,
      'Date of Birth': formatDateForExcel(member.dob),
      'Retirement Date': formatDateForExcel(member.retirement_date),
      'Share Amount': member.share_amount,
      'Thrift Deposit': member.thrift_deposit,
    }));

    exportToExcel(exportData, 'members', 'Members');
    toast.success('Members exported successfully');
  };

  const handleImport = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const data = await importFromExcel(file);
      
      for (const row of data) {
        const memberData = {
          member_number: row['Member Number'] || row['member_number'] || '',
          name: row['Name'] || row['name'] || '',
          dob: parseDateFromExcel(row['Date of Birth'] || row['dob']),
          retirement_date: parseDateFromExcel(row['Retirement Date'] || row['retirement_date']),
          share_amount: parseFloat(row['Share Amount'] || row['share_amount'] || '0'),
          thrift_deposit: parseFloat(row['Thrift Deposit'] || row['thrift_deposit'] || '0'),
        };

        await createMember(memberData);
      }

      toast.success(`Imported ${data.length} members successfully`);
      loadMembers();
    } catch (error) {
      toast.error('Failed to import members');
      console.error(error);
    }

    event.target.value = '';
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-primary text-primary-foreground py-4 px-4 sticky top-0 z-10 shadow-md">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-bold">Members</h1>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => loadMembers(true)}
            disabled={refreshing}
            className="text-primary-foreground hover:bg-primary-foreground/20"
          >
            <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </div>

      <div className="p-4 space-y-4">
        <div className="flex flex-wrap gap-2">
          <Button onClick={handleExport} variant="outline" size="sm" className="flex-1 min-w-[100px]">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Button variant="outline" size="sm" asChild className="flex-1 min-w-[100px]">
            <label htmlFor="import-members" className="cursor-pointer flex items-center justify-center">
              <Upload className="h-4 w-4 mr-2" />
              Import
              <input
                id="import-members"
                type="file"
                accept=".xlsx,.xls"
                onChange={handleImport}
                className="hidden"
              />
            </label>
          </Button>
          <Dialog open={dialogOpen} onOpenChange={(open) => {
            setDialogOpen(open);
            if (!open) {
              setEditingMember(null);
              form.reset();
            }
          }}>
            <DialogTrigger asChild>
              <Button size="sm" className="flex-1 min-w-[100px]">
                <Plus className="h-4 w-4 mr-2" />
                Add
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-[95vw] w-full max-h-[85vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingMember ? 'Edit Member' : 'Add New Member'}</DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="member_number"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Member Number</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="M001" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Name</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="John Doe" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="dob"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Date of Birth</FormLabel>
                        <FormControl>
                          <Input {...field} type="date" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="retirement_date"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Retirement Date</FormLabel>
                        <FormControl>
                          <Input {...field} type="date" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="share_amount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Share Amount</FormLabel>
                        <FormControl>
                          <Input {...field} type="number" step="0.01" placeholder="0.00" inputMode="decimal" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="thrift_deposit"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Thrift Deposit</FormLabel>
                        <FormControl>
                          <Input {...field} type="number" step="0.01" placeholder="0.00" inputMode="decimal" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <Button type="submit" className="w-full">
                    {editingMember ? 'Update Member' : 'Create Member'}
                  </Button>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>

        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map((i) => (
              <Card key={i}>
                <CardContent className="p-4">
                  <Skeleton className="h-4 w-24 mb-2 bg-muted" />
                  <Skeleton className="h-6 w-full mb-2 bg-muted" />
                  <Skeleton className="h-4 w-32 bg-muted" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : members.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <Users className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-muted-foreground">
                No members found. Add your first member to get started.
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {members.map((member) => (
              <Card key={member.id} className="overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs font-medium text-muted-foreground">
                          {member.member_number}
                        </span>
                      </div>
                      <h3 className="font-semibold text-lg">{member.name}</h3>
                    </div>
                    <div className="flex gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEdit(member)}
                        className="h-8 w-8 p-0"
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setMemberToDelete(member.id);
                          setDeleteDialogOpen(true);
                        }}
                        className="h-8 w-8 p-0"
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <p className="text-muted-foreground text-xs">DOB</p>
                      <p className="font-medium">
                        {member.dob ? new Date(member.dob).toLocaleDateString() : '-'}
                      </p>
                    </div>
                    <div>
                      <p className="text-muted-foreground text-xs">Retirement</p>
                      <p className="font-medium">
                        {member.retirement_date
                          ? new Date(member.retirement_date).toLocaleDateString()
                          : '-'}
                      </p>
                    </div>
                    <div>
                      <p className="text-muted-foreground text-xs">Share Amount</p>
                      <p className="font-medium">${member.share_amount.toFixed(2)}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground text-xs">Thrift Deposit</p>
                      <p className="font-medium">${member.thrift_deposit.toFixed(2)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent className="max-w-[90vw]">
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the member and all
              associated records.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default MembersPage;
