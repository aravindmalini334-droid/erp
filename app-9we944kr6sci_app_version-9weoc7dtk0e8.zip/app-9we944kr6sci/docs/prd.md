# ERP Mobile App Requirements Document

## 1. Application Overview

### 1.1 Application Name

ERP Mobile App

### 1.2 Application Description

A mobile ERP application that uses Excel files as a database, designed to manage members, loans, borrowings, and accounting ledgers with import/export capabilities.

## 2. Core Features

### 2.1 Members Tab

- Member number management
- Add new members
- Delete members
- Date of birth (DOB) tracking
- Date of retirement tracking
- Basic member details storage
- members share amount
- members thrift deposit amount

### 2.2 Members Loans Tab

- Loan disbursement functionality
- Loan collection tracking

### 2.3 Borrowings Tab

- Loan borrowing records
- Loan payment tracking

### 2.4 Accounting Ledgers Tab

- Day book
- General ledger
- Loan ledger
- expenses ledger with voucher

### 2.5 Data Management

- Import data from Excel sheets
- Export data as Excel sheets

## 3. Technical Requirements

### 3.1 Database

- Excel file as database storage

### 3.2 Platform

- Mobile application
