import React from 'react';
import { Users, DollarSign, TrendingUp, BookOpen } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';

const HomePage: React.FC = () => {
  const modules = [
    {
      title: 'Members',
      description: 'Manage member information, shares, and thrift deposits',
      icon: Users,
      path: '/members',
      color: 'bg-primary/10 text-primary',
    },
    {
      title: 'Loans',
      description: 'Handle loan disbursements and collections',
      icon: DollarSign,
      path: '/loans',
      color: 'bg-chart-2/10 text-chart-2',
    },
    {
      title: 'Borrowings',
      description: 'Track borrowings and payments',
      icon: TrendingUp,
      path: '/borrowings',
      color: 'bg-chart-3/10 text-chart-3',
    },
    {
      title: 'Ledgers',
      description: 'Maintain accounting ledgers and records',
      icon: BookOpen,
      path: '/ledgers',
      color: 'bg-chart-4/10 text-chart-4',
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-primary text-primary-foreground py-8 px-4">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-3xl font-bold mb-2">ERP Mobile App</h1>
          <p className="text-primary-foreground/90">
            Comprehensive management system for members, loans, and accounting
          </p>
        </div>
      </div>

      <div className="p-4 space-y-4">
        <div className="grid grid-cols-1 gap-3">
          {modules.map((module) => {
            const Icon = module.icon;
            return (
              <Link key={module.path} to={module.path}>
                <Card className="hover:shadow-md transition-shadow active:scale-[0.98] transition-transform">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-4">
                      <div className={`p-3 rounded-lg ${module.color}`}>
                        <Icon className="h-6 w-6" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg mb-1">{module.title}</h3>
                        <p className="text-sm text-muted-foreground">{module.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>

        <Card>
          <CardContent className="p-4">
            <h3 className="font-semibold mb-3">Features</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">✓</span>
                <span>Complete member management with DOB and retirement tracking</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">✓</span>
                <span>Loan disbursement and collection tracking</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">✓</span>
                <span>Borrowing records and payment management</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">✓</span>
                <span>Multiple accounting ledgers (Day Book, General, Loan, Expenses)</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">✓</span>
                <span>Excel import and export functionality for all modules</span>
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default HomePage;
