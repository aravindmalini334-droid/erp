import { supabase } from './supabase';
import type {
  Member,
  Loan,
  LoanCollection,
  Borrowing,
  BorrowingPayment,
  DayBook,
  GeneralLedger,
  LoanLedger,
  ExpensesLedger,
} from '@/types';

// Members API
export const getMembers = async (): Promise<Member[]> => {
  const { data, error } = await supabase
    .from('members')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const getMemberById = async (id: string): Promise<Member | null> => {
  const { data, error } = await supabase
    .from('members')
    .select('*')
    .eq('id', id)
    .maybeSingle();

  if (error) throw error;
  return data;
};

export const createMember = async (member: Omit<Member, 'id' | 'created_at' | 'updated_at'>) => {
  const { data, error } = await supabase
    .from('members')
    .insert([member])
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const updateMember = async (id: string, updates: Partial<Member>) => {
  const { data, error } = await supabase
    .from('members')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const deleteMember = async (id: string) => {
  const { error } = await supabase.from('members').delete().eq('id', id);
  if (error) throw error;
};

// Loans API
export const getLoans = async (): Promise<Loan[]> => {
  const { data, error } = await supabase
    .from('loans')
    .select('*, member:members(*)')
    .order('disbursement_date', { ascending: false });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const createLoan = async (loan: Omit<Loan, 'id' | 'created_at' | 'updated_at' | 'member'>) => {
  const { data, error } = await supabase
    .from('loans')
    .insert([loan])
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const updateLoan = async (id: string, updates: Partial<Loan>) => {
  const { data, error } = await supabase
    .from('loans')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .single();

  if (error) throw error;
  return data;
};

// Loan Collections API
export const getLoanCollections = async (loanId?: string): Promise<LoanCollection[]> => {
  let query = supabase
    .from('loan_collections')
    .select('*, loan:loans(*, member:members(*))');

  if (loanId) {
    query = query.eq('loan_id', loanId);
  }

  const { data, error } = await query.order('collection_date', { ascending: false });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const createLoanCollection = async (
  collection: Omit<LoanCollection, 'id' | 'created_at' | 'loan'>
) => {
  const { data, error } = await supabase
    .from('loan_collections')
    .insert([collection])
    .select()
    .single();

  if (error) throw error;
  return data;
};

// Borrowings API
export const getBorrowings = async (): Promise<Borrowing[]> => {
  const { data, error } = await supabase
    .from('borrowings')
    .select('*')
    .order('borrowing_date', { ascending: false });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const createBorrowing = async (
  borrowing: Omit<Borrowing, 'id' | 'created_at' | 'updated_at'>
) => {
  const { data, error } = await supabase
    .from('borrowings')
    .insert([borrowing])
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const updateBorrowing = async (id: string, updates: Partial<Borrowing>) => {
  const { data, error } = await supabase
    .from('borrowings')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .single();

  if (error) throw error;
  return data;
};

// Borrowing Payments API
export const getBorrowingPayments = async (borrowingId?: string): Promise<BorrowingPayment[]> => {
  let query = supabase
    .from('borrowing_payments')
    .select('*, borrowing:borrowings(*)');

  if (borrowingId) {
    query = query.eq('borrowing_id', borrowingId);
  }

  const { data, error } = await query.order('payment_date', { ascending: false });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const createBorrowingPayment = async (
  payment: Omit<BorrowingPayment, 'id' | 'created_at' | 'borrowing'>
) => {
  const { data, error } = await supabase
    .from('borrowing_payments')
    .insert([payment])
    .select()
    .single();

  if (error) throw error;
  return data;
};

// Day Book API
export const getDayBookEntries = async (): Promise<DayBook[]> => {
  const { data, error } = await supabase
    .from('day_book')
    .select('*')
    .order('entry_date', { ascending: false });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const createDayBookEntry = async (entry: Omit<DayBook, 'id' | 'created_at'>) => {
  const { data, error } = await supabase
    .from('day_book')
    .insert([entry])
    .select()
    .single();

  if (error) throw error;
  return data;
};

// General Ledger API
export const getGeneralLedgerEntries = async (): Promise<GeneralLedger[]> => {
  const { data, error } = await supabase
    .from('general_ledger')
    .select('*')
    .order('entry_date', { ascending: false });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const createGeneralLedgerEntry = async (entry: Omit<GeneralLedger, 'id' | 'created_at'>) => {
  const { data, error } = await supabase
    .from('general_ledger')
    .insert([entry])
    .select()
    .single();

  if (error) throw error;
  return data;
};

// Loan Ledger API
export const getLoanLedgerEntries = async (): Promise<LoanLedger[]> => {
  const { data, error } = await supabase
    .from('loan_ledger')
    .select('*, member:members(*)')
    .order('entry_date', { ascending: false });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const createLoanLedgerEntry = async (entry: Omit<LoanLedger, 'id' | 'created_at' | 'member'>) => {
  const { data, error } = await supabase
    .from('loan_ledger')
    .insert([entry])
    .select()
    .single();

  if (error) throw error;
  return data;
};

// Expenses Ledger API
export const getExpensesLedgerEntries = async (): Promise<ExpensesLedger[]> => {
  const { data, error } = await supabase
    .from('expenses_ledger')
    .select('*')
    .order('entry_date', { ascending: false });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const createExpensesLedgerEntry = async (entry: Omit<ExpensesLedger, 'id' | 'created_at'>) => {
  const { data, error } = await supabase
    .from('expenses_ledger')
    .insert([entry])
    .select()
    .single();

  if (error) throw error;
  return data;
};
