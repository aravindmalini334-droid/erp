import React, { useState, useEffect } from 'react';
import { Plus, Download, Upload, RefreshCw, TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { toast } from 'sonner';
import {
  getBorrowings,
  createBorrowing,
  getBorrowingPayments,
  createBorrowingPayment,
} from '@/db/api';
import type { Borrowing, BorrowingPayment } from '@/types';
import { exportToExcel, importFromExcel, formatDateForExcel, parseDateFromExcel } from '@/lib/excel';

const borrowingSchema = z.object({
  borrower_name: z.string().min(1, 'Borrower name is required'),
  borrowing_amount: z.string().min(1, 'Borrowing amount is required'),
  borrowing_date: z.string().min(1, 'Borrowing date is required'),
  notes: z.string().optional(),
});

const paymentSchema = z.object({
  borrowing_id: z.string().min(1, 'Borrowing is required'),
  payment_amount: z.string().min(1, 'Payment amount is required'),
  payment_date: z.string().min(1, 'Payment date is required'),
  notes: z.string().optional(),
});

type BorrowingFormData = z.infer<typeof borrowingSchema>;
type PaymentFormData = z.infer<typeof paymentSchema>;

const BorrowingsPage: React.FC = () => {
  const [borrowings, setBorrowings] = useState<Borrowing[]>([]);
  const [payments, setPayments] = useState<BorrowingPayment[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [borrowingDialogOpen, setBorrowingDialogOpen] = useState(false);
  const [paymentDialogOpen, setPaymentDialogOpen] = useState(false);

  const borrowingForm = useForm<BorrowingFormData>({
    resolver: zodResolver(borrowingSchema),
    defaultValues: {
      borrower_name: '',
      borrowing_amount: '',
      borrowing_date: new Date().toISOString().split('T')[0],
      notes: '',
    },
  });

  const paymentForm = useForm<PaymentFormData>({
    resolver: zodResolver(paymentSchema),
    defaultValues: {
      borrowing_id: '',
      payment_amount: '',
      payment_date: new Date().toISOString().split('T')[0],
      notes: '',
    },
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async (isRefresh = false) => {
    try {
      if (isRefresh) {
        setRefreshing(true);
      } else {
        setLoading(true);
      }
      const [borrowingsData, paymentsData] = await Promise.all([
        getBorrowings(),
        getBorrowingPayments(),
      ]);
      setBorrowings(borrowingsData);
      setPayments(paymentsData);
      if (isRefresh) {
        toast.success('Data refreshed');
      }
    } catch (error) {
      toast.error('Failed to load data');
      console.error(error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onBorrowingSubmit = async (data: BorrowingFormData) => {
    try {
      await createBorrowing({
        borrower_name: data.borrower_name,
        borrowing_amount: parseFloat(data.borrowing_amount),
        borrowing_date: data.borrowing_date,
        status: 'active',
        notes: data.notes || null,
      });

      toast.success('Borrowing recorded successfully');
      setBorrowingDialogOpen(false);
      borrowingForm.reset();
      loadData();
    } catch (error) {
      toast.error('Failed to record borrowing');
      console.error(error);
    }
  };

  const onPaymentSubmit = async (data: PaymentFormData) => {
    try {
      await createBorrowingPayment({
        borrowing_id: data.borrowing_id,
        payment_amount: parseFloat(data.payment_amount),
        payment_date: data.payment_date,
        notes: data.notes || null,
      });

      toast.success('Payment recorded successfully');
      setPaymentDialogOpen(false);
      paymentForm.reset();
      loadData();
    } catch (error) {
      toast.error('Failed to record payment');
      console.error(error);
    }
  };

  const handleExportBorrowings = () => {
    const exportData = borrowings.map((borrowing) => ({
      'Borrower Name': borrowing.borrower_name,
      'Borrowing Amount': borrowing.borrowing_amount,
      'Borrowing Date': formatDateForExcel(borrowing.borrowing_date),
      Status: borrowing.status,
      Notes: borrowing.notes || '',
    }));

    exportToExcel(exportData, 'borrowings', 'Borrowings');
    toast.success('Borrowings exported successfully');
  };

  const handleExportPayments = () => {
    const exportData = payments.map((payment) => ({
      'Borrower Name': payment.borrowing?.borrower_name || '',
      'Payment Amount': payment.payment_amount,
      'Payment Date': formatDateForExcel(payment.payment_date),
      Notes: payment.notes || '',
    }));

    exportToExcel(exportData, 'borrowing_payments', 'Payments');
    toast.success('Payments exported successfully');
  };

  const handleImportBorrowings = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const data = await importFromExcel(file);
      
      for (const row of data) {
        await createBorrowing({
          borrower_name: row['Borrower Name'] || row['borrower_name'] || '',
          borrowing_amount: parseFloat(row['Borrowing Amount'] || row['borrowing_amount'] || '0'),
          borrowing_date: parseDateFromExcel(row['Borrowing Date'] || row['borrowing_date']) || new Date().toISOString().split('T')[0],
          status: row['Status'] || row['status'] || 'active',
          notes: row['Notes'] || row['notes'] || null,
        });
      }

      toast.success(`Imported ${data.length} borrowings successfully`);
      loadData();
    } catch (error) {
      toast.error('Failed to import borrowings');
      console.error(error);
    }

    event.target.value = '';
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-primary text-primary-foreground py-4 px-4 sticky top-0 z-10 shadow-md">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-bold">Borrowings</h1>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => loadData(true)}
            disabled={refreshing}
            className="text-primary-foreground hover:bg-primary-foreground/20"
          >
            <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </div>

      <div className="p-4">
        <Tabs defaultValue="borrowings" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-4">
            <TabsTrigger value="borrowings">Borrowings</TabsTrigger>
            <TabsTrigger value="payments">Payments</TabsTrigger>
          </TabsList>

          <TabsContent value="borrowings" className="space-y-4 mt-0">
            <div className="flex flex-wrap gap-2">
              <Button onClick={handleExportBorrowings} variant="outline" size="sm" className="flex-1 min-w-[100px]">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
              <Button variant="outline" size="sm" asChild className="flex-1 min-w-[100px]">
                <label htmlFor="import-borrowings" className="cursor-pointer flex items-center justify-center">
                  <Upload className="h-4 w-4 mr-2" />
                  Import
                  <input
                    id="import-borrowings"
                    type="file"
                    accept=".xlsx,.xls"
                    onChange={handleImportBorrowings}
                    className="hidden"
                  />
                </label>
              </Button>
              <Dialog open={borrowingDialogOpen} onOpenChange={setBorrowingDialogOpen}>
                <DialogTrigger asChild>
                  <Button size="sm" className="flex-1 min-w-[100px]">
                    <Plus className="h-4 w-4 mr-2" />
                    Add
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-[95vw] w-full max-h-[85vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Record New Borrowing</DialogTitle>
                  </DialogHeader>
                  <Form {...borrowingForm}>
                    <form
                      onSubmit={borrowingForm.handleSubmit(onBorrowingSubmit)}
                      className="space-y-4"
                    >
                      <FormField
                        control={borrowingForm.control}
                        name="borrower_name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Borrower Name</FormLabel>
                            <FormControl>
                              <Input {...field} placeholder="Enter borrower name" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={borrowingForm.control}
                        name="borrowing_amount"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Borrowing Amount</FormLabel>
                            <FormControl>
                              <Input {...field} type="number" step="0.01" placeholder="0.00" inputMode="decimal" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={borrowingForm.control}
                        name="borrowing_date"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Borrowing Date</FormLabel>
                            <FormControl>
                              <Input {...field} type="date" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={borrowingForm.control}
                        name="notes"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Notes</FormLabel>
                            <FormControl>
                              <Textarea {...field} placeholder="Optional notes" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <Button type="submit" className="w-full">
                        Record Borrowing
                      </Button>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>

            {loading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <Card key={i}>
                    <CardContent className="p-4">
                      <Skeleton className="h-4 w-24 mb-2 bg-muted" />
                      <Skeleton className="h-6 w-full mb-2 bg-muted" />
                      <Skeleton className="h-4 w-32 bg-muted" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : borrowings.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <TrendingUp className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">
                    No borrowings found. Record your first borrowing to get started.
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {borrowings.map((borrowing) => (
                  <Card key={borrowing.id}>
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="font-semibold">{borrowing.borrower_name}</h3>
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-primary/10 text-primary">
                          {borrowing.status}
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div>
                          <p className="text-muted-foreground text-xs">Amount</p>
                          <p className="font-medium">${borrowing.borrowing_amount.toFixed(2)}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground text-xs">Date</p>
                          <p className="font-medium">{new Date(borrowing.borrowing_date).toLocaleDateString()}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="payments" className="space-y-4 mt-0">
            <div className="flex flex-wrap gap-2">
              <Button onClick={handleExportPayments} variant="outline" size="sm" className="flex-1 min-w-[120px]">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
              <Dialog open={paymentDialogOpen} onOpenChange={setPaymentDialogOpen}>
                <DialogTrigger asChild>
                  <Button size="sm" className="flex-1 min-w-[120px]">
                    <Plus className="h-4 w-4 mr-2" />
                    Record
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-[95vw] w-full max-h-[85vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Record Borrowing Payment</DialogTitle>
                  </DialogHeader>
                  <Form {...paymentForm}>
                    <form
                      onSubmit={paymentForm.handleSubmit(onPaymentSubmit)}
                      className="space-y-4"
                    >
                      <FormField
                        control={paymentForm.control}
                        name="borrowing_id"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Borrowing</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select borrowing" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {borrowings
                                  .filter((borrowing) => borrowing.status === 'active')
                                  .map((borrowing) => (
                                    <SelectItem key={borrowing.id} value={borrowing.id}>
                                      {borrowing.borrower_name} - ${borrowing.borrowing_amount.toFixed(2)}
                                    </SelectItem>
                                  ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={paymentForm.control}
                        name="payment_amount"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Payment Amount</FormLabel>
                            <FormControl>
                              <Input {...field} type="number" step="0.01" placeholder="0.00" inputMode="decimal" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={paymentForm.control}
                        name="payment_date"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Payment Date</FormLabel>
                            <FormControl>
                              <Input {...field} type="date" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={paymentForm.control}
                        name="notes"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Notes</FormLabel>
                            <FormControl>
                              <Textarea {...field} placeholder="Optional notes" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <Button type="submit" className="w-full">
                        Record Payment
                      </Button>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>

            {loading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <Card key={i}>
                    <CardContent className="p-4">
                      <Skeleton className="h-4 w-24 mb-2 bg-muted" />
                      <Skeleton className="h-6 w-full mb-2 bg-muted" />
                      <Skeleton className="h-4 w-32 bg-muted" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : payments.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <TrendingUp className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">
                    No payments found. Record your first payment to get started.
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {payments.map((payment) => (
                  <Card key={payment.id}>
                    <CardContent className="p-4">
                      <h3 className="font-semibold mb-2">{payment.borrowing?.borrower_name}</h3>
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div>
                          <p className="text-muted-foreground text-xs">Amount</p>
                          <p className="font-medium">${payment.payment_amount.toFixed(2)}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground text-xs">Date</p>
                          <p className="font-medium">{new Date(payment.payment_date).toLocaleDateString()}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default BorrowingsPage;
