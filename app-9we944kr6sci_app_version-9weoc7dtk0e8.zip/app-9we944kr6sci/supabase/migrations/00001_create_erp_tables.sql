-- Create members table
CREATE TABLE members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  member_number TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  dob DATE,
  retirement_date DATE,
  share_amount DECIMAL(12, 2) DEFAULT 0,
  thrift_deposit DECIMAL(12, 2) DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create loans table
CREATE TABLE loans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  member_id UUID REFERENCES members(id) ON DELETE CASCADE,
  loan_amount DECIMAL(12, 2) NOT NULL,
  disbursement_date DATE NOT NULL,
  status TEXT DEFAULT 'active',
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create loan_collections table
CREATE TABLE loan_collections (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  loan_id UUID REFERENCES loans(id) ON DELETE CASCADE,
  collection_amount DECIMAL(12, 2) NOT NULL,
  collection_date DATE NOT NULL,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create borrowings table
CREATE TABLE borrowings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  borrower_name TEXT NOT NULL,
  borrowing_amount DECIMAL(12, 2) NOT NULL,
  borrowing_date DATE NOT NULL,
  status TEXT DEFAULT 'active',
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create borrowing_payments table
CREATE TABLE borrowing_payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  borrowing_id UUID REFERENCES borrowings(id) ON DELETE CASCADE,
  payment_amount DECIMAL(12, 2) NOT NULL,
  payment_date DATE NOT NULL,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create day_book table
CREATE TABLE day_book (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  entry_date DATE NOT NULL,
  description TEXT NOT NULL,
  debit DECIMAL(12, 2) DEFAULT 0,
  credit DECIMAL(12, 2) DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create general_ledger table
CREATE TABLE general_ledger (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  entry_date DATE NOT NULL,
  account_name TEXT NOT NULL,
  description TEXT NOT NULL,
  debit DECIMAL(12, 2) DEFAULT 0,
  credit DECIMAL(12, 2) DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create loan_ledger table
CREATE TABLE loan_ledger (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  entry_date DATE NOT NULL,
  member_id UUID REFERENCES members(id) ON DELETE SET NULL,
  description TEXT NOT NULL,
  debit DECIMAL(12, 2) DEFAULT 0,
  credit DECIMAL(12, 2) DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create expenses_ledger table
CREATE TABLE expenses_ledger (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  entry_date DATE NOT NULL,
  description TEXT NOT NULL,
  amount DECIMAL(12, 2) NOT NULL,
  voucher_number TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create indexes for better performance
CREATE INDEX idx_members_member_number ON members(member_number);
CREATE INDEX idx_loans_member_id ON loans(member_id);
CREATE INDEX idx_loan_collections_loan_id ON loan_collections(loan_id);
CREATE INDEX idx_borrowings_status ON borrowings(status);
CREATE INDEX idx_borrowing_payments_borrowing_id ON borrowing_payments(borrowing_id);
CREATE INDEX idx_day_book_date ON day_book(entry_date);
CREATE INDEX idx_general_ledger_date ON general_ledger(entry_date);
CREATE INDEX idx_loan_ledger_date ON loan_ledger(entry_date);
CREATE INDEX idx_expenses_ledger_date ON expenses_ledger(entry_date);

-- Enable RLS
ALTER TABLE members ENABLE ROW LEVEL SECURITY;
ALTER TABLE loans ENABLE ROW LEVEL SECURITY;
ALTER TABLE loan_collections ENABLE ROW LEVEL SECURITY;
ALTER TABLE borrowings ENABLE ROW LEVEL SECURITY;
ALTER TABLE borrowing_payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE day_book ENABLE ROW LEVEL SECURITY;
ALTER TABLE general_ledger ENABLE ROW LEVEL SECURITY;
ALTER TABLE loan_ledger ENABLE ROW LEVEL SECURITY;
ALTER TABLE expenses_ledger ENABLE ROW LEVEL SECURITY;

-- Create policies for public access (no auth required)
CREATE POLICY "Allow all operations on members" ON members FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on loans" ON loans FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on loan_collections" ON loan_collections FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on borrowings" ON borrowings FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on borrowing_payments" ON borrowing_payments FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on day_book" ON day_book FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on general_ledger" ON general_ledger FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on loan_ledger" ON loan_ledger FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all operations on expenses_ledger" ON expenses_ledger FOR ALL USING (true) WITH CHECK (true);