// Database types for ERP Mobile App

export interface Member {
  id: string;
  member_number: string;
  name: string;
  dob: string | null;
  retirement_date: string | null;
  share_amount: number;
  thrift_deposit: number;
  created_at: string;
  updated_at: string;
}

export interface Loan {
  id: string;
  member_id: string;
  loan_amount: number;
  disbursement_date: string;
  status: string;
  notes: string | null;
  created_at: string;
  updated_at: string;
  member?: Member;
}

export interface LoanCollection {
  id: string;
  loan_id: string;
  collection_amount: number;
  collection_date: string;
  notes: string | null;
  created_at: string;
  loan?: Loan;
}

export interface Borrowing {
  id: string;
  borrower_name: string;
  borrowing_amount: number;
  borrowing_date: string;
  status: string;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface BorrowingPayment {
  id: string;
  borrowing_id: string;
  payment_amount: number;
  payment_date: string;
  notes: string | null;
  created_at: string;
  borrowing?: Borrowing;
}

export interface DayBook {
  id: string;
  entry_date: string;
  description: string;
  debit: number;
  credit: number;
  created_at: string;
}

export interface GeneralLedger {
  id: string;
  entry_date: string;
  account_name: string;
  description: string;
  debit: number;
  credit: number;
  created_at: string;
}

export interface LoanLedger {
  id: string;
  entry_date: string;
  member_id: string | null;
  description: string;
  debit: number;
  credit: number;
  created_at: string;
  member?: Member;
}

export interface ExpensesLedger {
  id: string;
  entry_date: string;
  description: string;
  amount: number;
  voucher_number: string | null;
  created_at: string;
}
